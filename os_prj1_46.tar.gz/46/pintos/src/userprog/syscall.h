#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "threads/thread.h"
void syscall_init (void);

void is_valid_addr(void* addr);
void syscall_halt(void);
tid_t syscall_exec(char *cmd_line);
int syscall_write(int fd, const void *buffer, unsigned size);
int  syscall_read(int fd, const void *buffer, unsigned size);
int syscall_wait(tid_t pid);
void syscall_exit(int status);
int syscall_fibonacci(int n);
int syscall_sum_four(int a, int b, int c, int d);

#endif /* userprog/syscall.h */
