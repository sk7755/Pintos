#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include <string.h>
#include "userprog/process.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);


#define SYSCALL_DEBUG_MODE 0

void is_valid_addr(void* addr)
{
	if(!is_user_vaddr(addr))
		syscall_exit(-1);
	return;
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f) 
{
 //printf ("system call!\n");
 if(SYSCALL_DEBUG_MODE)
 {
	hex_dump((int)f->esp, f->esp, 150,true);
	printf("sys call number %d\n",*(int*)(f->esp));
 }
 uint32_t* arg = (uint32_t*)f->esp;


 uint32_t syscall_num = arg[0];

  switch(syscall_num)
  {
	  case SYS_HALT:
		  is_valid_addr(arg);
		  syscall_halt();
		  break;
	  case SYS_EXEC:
		  is_valid_addr(arg+1);
		  f->eax = syscall_exec((char*)arg[1]);
		  break;
	  case SYS_WAIT:
		  is_valid_addr(arg+1);
		  f->eax = syscall_wait((int)arg[1]);
		  break;
	  case SYS_WRITE:
		  is_valid_addr(arg+3);
		  f->eax = syscall_write((int)arg[1],(void*)arg[2],(unsigned)arg[3]);
		  break;
	  case SYS_READ:
		  is_valid_addr(arg+3);
		  f->eax = syscall_read((int)arg[1],(void*)arg[2],(unsigned)arg[3]);
		  break;
	case SYS_FIBONACCI:
		  is_valid_addr(arg+1);
		  f->eax = syscall_fibonacci((int)arg[1]);
		  break;
	case SYS_SUM_FOUR:
		  is_valid_addr(arg+4);
		  f->eax = syscall_sum_four((int)arg[1], (int)arg[2], (int)arg[3], (int)arg[4]);
		  break;
	case SYS_EXIT:
		  is_valid_addr(arg+1);
		  syscall_exit((int)arg[1]);
		  break;
	
  }

  if(SYSCALL_DEBUG_MODE)
	  printf("-----------------------------------\n");
}

void syscall_halt(void)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL READ\n");
	shutdown_power_off();
}

tid_t syscall_exec(char *cmd_line)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL EXEC %s\n",cmd_line);
	
	tid_t tid = process_execute(cmd_line);
	if(tid == TID_ERROR)
		return -1;
	while(true)
	{
		struct thread_info* p = thread_info_find(tid);
		if(p == NULL)
			return -1;
		else
		{
			if(p->load == 1)
				return tid;
			else if(p->load == -1)
				return -1;
		}
	}
}

int syscall_wait(tid_t pid)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL WAIT %d\n",pid);
	
	return  process_wait(pid);
}

int syscall_write(int fd, const void *buffer, unsigned size)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL WRITE %u %p %u\n",fd,buffer,size);
	
	if(fd == 1)
		putbuf(buffer,size);
	return size;
}

int syscall_read(int fd, const void *buffer, unsigned size)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL READ %u %p %u\n",fd,buffer,size);
	
	if(fd == 0)
	{
		unsigned i;
		for(i = 0 ; i <size;i++)
		{
			*(char*)(buffer+i) = input_getc();
		}	
	}
	return size;	
}


void syscall_exit(int status)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL EXIT %d\n",status);

	const char* name = thread_name();
	int i = 0;
	while(name[i] != ' ' && name[i] != '\0')
		i++;
	i++;
	if(i > 16)
		i = 16;
	char tmp_name[16];
	strlcpy(tmp_name,name,i);

	printf("%s: exit(%d)\n",tmp_name,status);
	thread_exit_status(status);
}

int syscall_fibonacci(int n)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL PIBONACCI %d\n",n);

	int i;
	int fibo[3] = {0,1,};
	if(n <= 1)
		return fibo[n];
	for(i = 2 ; i <= n;i++)
	{
		fibo[i%3] = fibo[(i-1)%3] + fibo[(i-2)%3];
	}


	return fibo[(i-1)%3];
}

int syscall_sum_four(int a, int b, int c, int d)
{
	if(SYSCALL_DEBUG_MODE)
		printf("SYS CALL SUM FOUR %d %d %d %d\n",a,b,c,d);

	return a+b+c+d;
}
